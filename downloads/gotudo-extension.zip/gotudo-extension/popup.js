const DEFAULTS = { enabled: true, method: 'telex', modern: true, auto: true, autocorrect: true, suggestBar: true, mode: 'vi', indicator: true, hotkey: 'ctrl+shift', disabledSites: [] };
let cfg, host = '';
async function load() {
  const r = await chrome.storage.sync.get('gotudo'); cfg = Object.assign({}, DEFAULTS, r.gotudo || {});
  try { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); host = new URL(tab.url).hostname; } catch (e) { host = ''; }
  render();
}
function render() {
  document.querySelectorAll('[data-k]').forEach((el) => { const k = el.dataset.k; if (el.tagName === 'SELECT') el.value = cfg[k]; else el.checked = !!cfg[k]; });
  document.getElementById('vi').className = 'vi' + (cfg.enabled && cfg.mode === 'vi' ? ' on' : '');
  document.getElementById('en').className = 'en' + (cfg.enabled && cfg.mode === 'en' ? ' on' : '');
  document.getElementById('off').className = !cfg.enabled ? 'on' : '';
  document.getElementById('site').checked = (cfg.disabledSites || []).includes(host);
}
async function save() { await chrome.storage.sync.set({ gotudo: cfg }); render(); }
document.querySelectorAll('[data-k]').forEach((el) => el.addEventListener('change', () => { cfg[el.dataset.k] = el.tagName === 'SELECT' ? el.value : el.checked; save(); }));
document.getElementById('vi').onclick = () => { cfg.enabled = true; cfg.mode = 'vi'; save(); };
document.getElementById('en').onclick = () => { cfg.enabled = true; cfg.mode = 'en'; save(); };
document.getElementById('off').onclick = () => { cfg.enabled = false; save(); };
document.getElementById('site').onchange = (e) => { const s = new Set(cfg.disabledSites || []); e.target.checked ? s.add(host) : s.delete(host); cfg.disabledSites = [...s]; save(); };
load();
